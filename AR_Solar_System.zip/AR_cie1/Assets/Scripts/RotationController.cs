using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotationController : MonoBehaviour
{
    public GameObject planetObj;
    public Vector3 rotationvector;

    public void Update()
    {
         planetObj.transform.Rotate(rotationvector * Time.deltaTime);
    }
}
